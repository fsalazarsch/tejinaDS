#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <3ds.h>
#include <citro2d.h>
#include <wchar.h>
#include "functions.h"


void kbd_init();
void kbd_render(C2D_TextBuf g_staticBuf);
void kbd_exit();

#endif