/* =========================================================
   FILE: lesson.c
   ========================================================= */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "lesson.h"

static void trim_newline(char* str)
{
    int len = strlen(str);

    while(len > 0 &&
         (str[len - 1] == '\n' ||
          str[len - 1] == '\r'))
    {
        str[len - 1] = '\0';
        len--;
    }
}

static BlockType get_block_type(const char* name)
{
    if(strcmp(name, "dialog") == 0) return BLOCK_DIALOG;
    if(strcmp(name, "term") == 0) return BLOCK_TERM;
    if(strcmp(name, "compare") == 0) return BLOCK_COMPARE;
    if(strcmp(name, "example") == 0) return BLOCK_EXAMPLE;
    if(strcmp(name, "sequence") == 0) return BLOCK_SEQUENCE;
    if(strcmp(name, "grammar_box") == 0) return BLOCK_GRAMMAR_BOX;
    if(strcmp(name, "particle") == 0) return BLOCK_PARTICLE;
    if(strcmp(name, "breakdown") == 0) return BLOCK_BREAKDOWN;
    if(strcmp(name, "quiz") == 0) return BLOCK_QUIZ;
    if(strcmp(name, "summary") == 0) return BLOCK_SUMMARY;
    if(strcmp(name, "sfx") == 0) return BLOCK_SFX;
    if(strcmp(name, "reward") == 0) return BLOCK_REWARD;
    if(strcmp(name, "unlock") == 0) return BLOCK_UNLOCK;

    return BLOCK_NONE;
}

static void set_field(LessonBlock* block,
                      const char* key,
                      const char* value)
{
    switch(block->type)
    {
        case BLOCK_DIALOG:

            if(strcmp(key, "portrait") == 0)
                strcpy(block->field1, value);

            else if(strcmp(key, "name") == 0)
                strcpy(block->field2, value);

            else if(strcmp(key, "text") == 0)
                strcpy(block->field3, value);

            break;

        case BLOCK_EXAMPLE:

            if(strcmp(key, "jp") == 0)
                strcpy(block->field1, value);

            else if(strcmp(key, "romaji") == 0)
                strcpy(block->field2, value);

            else if(strcmp(key, "es") == 0)
                strcpy(block->field3, value);

            break;

        case BLOCK_QUIZ:

            if(strcmp(key, "question") == 0)
                strcpy(block->field1, value);

            else if(strcmp(key, "a") == 0)
                strcpy(block->field2, value);

            else if(strcmp(key, "b") == 0)
                strcpy(block->field3, value);

            else if(strcmp(key, "c") == 0)
                strcpy(block->field4, value);

            else if(strcmp(key, "correct") == 0)
                strcpy(block->field5, value);

            else if(strcmp(key, "success_text") == 0)
                strcpy(block->field6, value);

            break;

        default:

            if(strcmp(key, "text") == 0)
                strcpy(block->field1, value);

            break;
    }
}

int lesson_load(const char* filename, Lesson* lesson)
{
    FILE* fp;
    char line[512];

    LessonBlock* currentBlock = NULL;

    fp = fopen(filename, "r");

    if(!fp)
        return 0;

    memset(lesson, 0, sizeof(Lesson));

    while(fgets(line, sizeof(line), fp))
    {
        trim_newline(line);

        if(strlen(line) == 0)
            continue;

        if(line[0] == '#')
            continue;

        /* =================================================
           METADATA
           ================================================= */

        if(line[0] == '@')
        {
            char* eq = strchr(line, '=');

            if(!eq)
                continue;

            *eq = '\0';

            char* key = line + 1;
            char* value = eq + 1;

            if(strcmp(key, "lesson_id") == 0)
                strcpy(lesson->lessonId, value);

            else if(strcmp(key, "title") == 0)
                strcpy(lesson->title, value);

            else if(strcmp(key, "category") == 0)
                strcpy(lesson->category, value);

            else if(strcmp(key, "bg") == 0)
                strcpy(lesson->background, value);

            continue;
        }

        /* =================================================
           BLOCK START
           ================================================= */

        if(line[0] == '[')
        {
            char blockName[64];

            sscanf(line, "[%63[^]]", blockName);

            currentBlock =
                &lesson->blocks[lesson->totalBlocks++];

            memset(currentBlock, 0, sizeof(LessonBlock));

            currentBlock->type =
                get_block_type(blockName);

            continue;
        }

        /* =================================================
           FIELD
           ================================================= */

        if(currentBlock)
        {
            char* eq = strchr(line, '=');

            if(!eq)
                continue;

            *eq = '\0';

            char* key = line;
            char* value = eq + 1;

            set_field(currentBlock, key, value);
        }
    }

    fclose(fp);

    return 1;
}