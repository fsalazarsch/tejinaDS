/* =========================================================
   FILE: lesson.h
   ========================================================= */

#ifndef LESSON_H
#define LESSON_H

#define MAX_BLOCKS 256
#define MAX_STR    256

typedef enum
{
    BLOCK_NONE,

    BLOCK_DIALOG,
    BLOCK_TERM,
    BLOCK_COMPARE,
    BLOCK_EXAMPLE,
    BLOCK_SEQUENCE,
    BLOCK_GRAMMAR_BOX,
    BLOCK_PARTICLE,
    BLOCK_BREAKDOWN,
    BLOCK_QUIZ,
    BLOCK_SUMMARY,
    BLOCK_SFX,
    BLOCK_REWARD,
    BLOCK_UNLOCK

} BlockType;

typedef struct
{
    BlockType type;

    char field1[MAX_STR];
    char field2[MAX_STR];
    char field3[MAX_STR];
    char field4[MAX_STR];
    char field5[MAX_STR];
    char field6[MAX_STR];

} LessonBlock;

typedef struct
{
    char lessonId[64];
    char title[64];
    char category[64];
    char background[64];

    int totalBlocks;

    LessonBlock blocks[MAX_BLOCKS];

} Lesson;

int lesson_load(const char* filename, Lesson* lesson);

#endif