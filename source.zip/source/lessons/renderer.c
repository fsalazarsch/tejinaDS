/* =========================================================
   FILE: renderer.c
   ========================================================= */

#include <stdio.h>
#include "lesson.h"

void render_dialog(LessonBlock* block)
{

    FILE *f = fopen("sdmc:/lesson.txt", "a");
    
    fprintf(f,"\n");
    fprintf(f,"[DIALOG]\n");
    fprintf(f,"Portrait: %s\n", block->field1);
    fprintf(f,"%s: %s\n",
           block->field2,
           block->field3);

    fclose(f);

}

void render_example(LessonBlock* block)
{
    printf("\n");
    printf("[EXAMPLE]\n");

    printf("JP: %s\n", block->field1);
    printf("RO: %s\n", block->field2);
    printf("ES: %s\n", block->field3);
}

void render_quiz(LessonBlock* block)
{
    printf("\n");
    printf("[QUIZ]\n");

    printf("%s\n", block->field1);

    printf("A) %s\n", block->field2);
    printf("B) %s\n", block->field3);
    printf("C) %s\n", block->field4);
}

void lesson_render(Lesson* lesson)
{
    int i;

    printf("\n");
    printf("====================================\n");
    printf("%s\n", lesson->title);
    printf("====================================\n");

    for(i = 0; i < lesson->totalBlocks; i++)
    {
        LessonBlock* block =
            &lesson->blocks[i];

        switch(block->type)
        {
            case BLOCK_DIALOG:
                render_dialog(block);
                break;

            case BLOCK_EXAMPLE:
                render_example(block);
                break;

            case BLOCK_QUIZ:
                render_quiz(block);
                break;

            default:
                break;
        }
    }
}