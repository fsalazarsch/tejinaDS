#ifndef KANA_TABLE_SCREEN_H
#define KANA_TABLE_SCREEN_H


#include "tabla.h"
#include "themes.h"
#include "aprender/escritura/kanji/kanji_stroke_data.h"
#include "tts_engine.h"
#include "aprender/escritura/drawing_view/drawing_view.h"



#define X_INICIAL  20
#define Y_INICIAL  50
#define ANCHO_CELDA 36
#define ALTO_CELDA  34

void draw_kana_detail(C3D_RenderTarget *bottom,
                      C2D_TextBuf g_staticBuf,
                      C2D_Font font1,
                      C2D_Font font2,
                      TablaState *estado);

void handle_tabla_touch(u32 kDown, u32 kHeld, u32 kUp, int tx, int ty, TablaState *estado);
void mostrar_tabla(C3D_RenderTarget*, C3D_RenderTarget*, C2D_TextBuf, C2D_Font, C2D_Font, TablaState*);
int kana_handle_input(u32 kDown, u32 kHeld, u32 kUp, int tx, int ty);

#endif



